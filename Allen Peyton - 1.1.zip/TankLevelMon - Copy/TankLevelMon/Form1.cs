﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TankLevelMon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Variables
        double num1, num2, result;
        char calc;
        bool dec = false;

        // The next bit is mistaken clicks and the form freaks out if I delete them.  Once I figure that out Ill clean this up.
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void lblAng_Click(object sender, EventArgs e)
        {
            
        }

        //  Update on Dia Change.
        private void updateDiameter(object sender, EventArgs e)
        {
            lblAngUdate();
        }
        private void DecBtn_Click(object sender, EventArgs e)
        {
            //Change the string to something I can work with.
            double sensorValue = float.Parse(lblSensorRead.Text); // Store the sensor value in a variable
            Console.WriteLine("DecBtn clicked, sensor value: " + sensorValue);

            if (sensorValue <= 0.0)
            {
                //Set the minimum value and Back to string to print
                result = 0.0;
                lblSensorRead.Text = Convert.ToString(result);
            }
            else
            {
                num1 = .1;
                num2 = sensorValue;
                result = num2 - num1;
                //having trouble with random trailing zeros after the first button push.  Adding rounding to address it.
                result = Math.Round(result, 2);
                lblSensorRead.Text = Convert.ToString(result);
            }

            Console.WriteLine("DecBtn result: " + result);  // Output result after the operation...  Debug
            lblAngUdate();
        }

        private void IncBtn_Click(object sender, EventArgs e)
        {
            double sensorValue = float.Parse(lblSensorRead.Text); // Store the sensor value in a variable
            Console.WriteLine("IncBtn clicked, sensor value: " + sensorValue);

            // Set the limits of the Sensor Value.  Could add text box input to make it a little more dynamic.
            if (sensorValue >= 5.0)
            {
                result = 5.0;
                lblSensorRead.Text = Convert.ToString(result);
            }
            else
            {
                num1 = .1;
                num2 = sensorValue;
                result = num1 + num2;
                //having trouble with random trailing zeros after the first button push.  Adding rounding to address it.
                result = Math.Round(result, 2);
                lblSensorRead.Text = Convert.ToString(result);
            }

            Console.WriteLine("IncBtn result: " + result);  // Output result after the operation....  Debug
            lblAngUdate();  // Call the update function
        }

        private void lblAngUdate()
        {
            //variable needed for callculations
            double matHeight;
            double sensorValue;
            double psiRead;
            double calcGallon;
            double tankVolume;
            double tankRadius;
            double lvlRound;
            int lvlBarValue;

            //progress bar range
            lvlBar.Minimum = 0;
            lvlBar.Maximum = 100;
        
            lblAng.Text = lblSensorRead.Text;

            //more converting and math
            psiRead = Convert.ToDouble(lblSensorRead.Text);
            psiRead = psiRead * 2; // in this case we are using a 0-10 psi sensor with a 0-5 v output.  Makes conversion simple x2
            lblPress.Text = Convert.ToString(psiRead);
         
            matHeight = Math.Round(psiRead * 26.78, 2); //   * 26.78 to get the inches of material above the sensor.
            lblHeight.Text = Convert.ToString(matHeight);

            tankRadius = Convert.ToDouble(txtRadius.Text); // convert the tank diameter textbox to radius for calculations
            tankRadius = tankRadius / 2;
            tankVolume = Math.Round(Math.PI * (tankRadius * tankRadius) * matHeight, 2); // calc the cubic inches of material.
            calcGallon = Math.Round(tankVolume / 231, 2); // cubic inches in a gallon;
            lblGallon.Text = Convert.ToString(calcGallon);

            lvlRound = Convert.ToDouble(lblSensorRead.Text);
            lvlRound = lvlRound * 20;
            lvlBarValue = Convert.ToInt16(lvlRound);
            
            Console.WriteLine("lvlBar Value: " + lvlBarValue); //Debugg

            //  Have not figured out how to change the color of the progress bar.  The internet says I am out of luck until I get better.
            lvlBar.Value = lvlBarValue;
            lvlBarY.Value = lvlBarValue;
            lvlBarG.Value = lvlBarValue;
            

            //I want to change the color of the progress bar but I have to settle for the label text for now.
            if (lvlBarValue <= 20)
            {
                label9.ForeColor = Color.Red;
            }
            else if ( lvlBarValue <= 79)
            {
                label9.ForeColor = Color.DarkOrange;
            }
            else
            {
                label9.ForeColor = Color.Green;
            }
        }

    }
}