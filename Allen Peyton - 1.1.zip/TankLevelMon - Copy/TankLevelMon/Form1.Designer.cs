﻿namespace TankLevelMon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.IncBtn = new System.Windows.Forms.Button();
            this.DecBtn = new System.Windows.Forms.Button();
            this.lblSensorRead = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblAng = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblPress = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtRadius = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lblGallon = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lvlBar = new System.Windows.Forms.ProgressBar();
            this.label9 = new System.Windows.Forms.Label();
            this.lvlBarY = new System.Windows.Forms.ProgressBar();
            this.lvlBarG = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 384);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sensor Value";
            // 
            // IncBtn
            // 
            this.IncBtn.BackColor = System.Drawing.Color.Lime;
            this.IncBtn.Location = new System.Drawing.Point(114, 467);
            this.IncBtn.Name = "IncBtn";
            this.IncBtn.Size = new System.Drawing.Size(75, 40);
            this.IncBtn.TabIndex = 2;
            this.IncBtn.Text = "+";
            this.IncBtn.UseVisualStyleBackColor = false;
            this.IncBtn.Click += new System.EventHandler(this.IncBtn_Click);
            // 
            // DecBtn
            // 
            this.DecBtn.BackColor = System.Drawing.Color.Red;
            this.DecBtn.Location = new System.Drawing.Point(210, 468);
            this.DecBtn.Name = "DecBtn";
            this.DecBtn.Size = new System.Drawing.Size(75, 39);
            this.DecBtn.TabIndex = 3;
            this.DecBtn.Text = "-";
            this.DecBtn.UseVisualStyleBackColor = false;
            this.DecBtn.Click += new System.EventHandler(this.DecBtn_Click);
            // 
            // lblSensorRead
            // 
            this.lblSensorRead.AutoSize = true;
            this.lblSensorRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSensorRead.Location = new System.Drawing.Point(170, 426);
            this.lblSensorRead.Name = "lblSensorRead";
            this.lblSensorRead.Size = new System.Drawing.Size(58, 29);
            this.lblSensorRead.TabIndex = 4;
            this.lblSensorRead.Text = "0.00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(109, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(233, 29);
            this.label2.TabIndex = 5;
            this.label2.Text = "Sensor Information";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(109, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 25);
            this.label3.TabIndex = 6;
            this.label3.Text = "Type: Pressure";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Signal: Analog";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(109, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(163, 25);
            this.label5.TabIndex = 8;
            this.label5.Text = "Range: 0 - 5 vDC";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(114, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 25);
            this.label6.TabIndex = 9;
            this.label6.Text = "ADC: 4095";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(84, 344);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(248, 29);
            this.label7.TabIndex = 10;
            this.label7.Text = "Simulate the Sensor";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(412, 86);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(165, 29);
            this.label8.TabIndex = 11;
            this.label8.Text = "Analog Input:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // lblAng
            // 
            this.lblAng.AutoSize = true;
            this.lblAng.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAng.Location = new System.Drawing.Point(608, 86);
            this.lblAng.Name = "lblAng";
            this.lblAng.Size = new System.Drawing.Size(0, 29);
            this.lblAng.TabIndex = 12;
            this.lblAng.Click += new System.EventHandler(this.lblAng_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(393, 127);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(184, 29);
            this.label12.TabIndex = 15;
            this.label12.Text = "Calc Pressure:";
            // 
            // lblPress
            // 
            this.lblPress.AutoSize = true;
            this.lblPress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPress.Location = new System.Drawing.Point(608, 127);
            this.lblPress.Name = "lblPress";
            this.lblPress.Size = new System.Drawing.Size(0, 29);
            this.lblPress.TabIndex = 16;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(415, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(162, 29);
            this.label14.TabIndex = 17;
            this.label14.Text = "Fluid Height:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHeight.Location = new System.Drawing.Point(608, 171);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(0, 29);
            this.lblHeight.TabIndex = 18;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(89, 264);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(232, 31);
            this.label16.TabIndex = 19;
            this.label16.Text = "Tank Diameter (in)";
            // 
            // txtRadius
            // 
            this.txtRadius.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRadius.Location = new System.Drawing.Point(155, 307);
            this.txtRadius.Name = "txtRadius";
            this.txtRadius.Size = new System.Drawing.Size(100, 34);
            this.txtRadius.TabIndex = 20;
            this.txtRadius.Text = "102";
            this.txtRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtRadius.TextChanged += new System.EventHandler(this.updateDiameter);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(468, 220);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 29);
            this.label17.TabIndex = 21;
            this.label17.Text = "Gallons:";
            // 
            // lblGallon
            // 
            this.lblGallon.AutoSize = true;
            this.lblGallon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGallon.Location = new System.Drawing.Point(613, 220);
            this.lblGallon.Name = "lblGallon";
            this.lblGallon.Size = new System.Drawing.Size(0, 29);
            this.lblGallon.TabIndex = 22;
            // 
            // lvlBar
            // 
            this.lvlBar.ForeColor = System.Drawing.Color.Red;
            this.lvlBar.Location = new System.Drawing.Point(411, 384);
            this.lvlBar.Name = "lvlBar";
            this.lvlBar.Size = new System.Drawing.Size(259, 63);
            this.lvlBar.Step = 2;
            this.lvlBar.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(429, 341);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(219, 29);
            this.label9.TabIndex = 24;
            this.label9.Text = "Tank Level Visual";
            // 
            // lvlBarY
            // 
            this.lvlBarY.ForeColor = System.Drawing.Color.Yellow;
            this.lvlBarY.Location = new System.Drawing.Point(411, 453);
            this.lvlBarY.Name = "lvlBarY";
            this.lvlBarY.Size = new System.Drawing.Size(259, 63);
            this.lvlBarY.Step = 2;
            this.lvlBarY.TabIndex = 25;
            this.lvlBarY.Visible = false;
            // 
            // lvlBarG
            // 
            this.lvlBarG.BackColor = System.Drawing.Color.ForestGreen;
            this.lvlBarG.ForeColor = System.Drawing.Color.ForestGreen;
            this.lvlBarG.Location = new System.Drawing.Point(411, 453);
            this.lvlBarG.Name = "lvlBarG";
            this.lvlBarG.Size = new System.Drawing.Size(259, 63);
            this.lvlBarG.Step = 2;
            this.lvlBarG.TabIndex = 26;
            this.lvlBarG.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(785, 561);
            this.Controls.Add(this.lvlBarG);
            this.Controls.Add(this.lvlBarY);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lvlBar);
            this.Controls.Add(this.lblGallon);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtRadius);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblHeight);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.lblPress);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblAng);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblSensorRead);
            this.Controls.Add(this.DecBtn);
            this.Controls.Add(this.IncBtn);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Level Monitor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button IncBtn;
        private System.Windows.Forms.Button DecBtn;
        private System.Windows.Forms.Label lblSensorRead;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblAng;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblPress;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtRadius;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblGallon;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ProgressBar lvlBar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ProgressBar lvlBarY;
        private System.Windows.Forms.ProgressBar lvlBarG;
    }
}

