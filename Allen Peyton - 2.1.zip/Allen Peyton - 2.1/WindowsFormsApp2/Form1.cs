﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class startBtn : Form
    {

        // Allen Peyton 
        //  The general idea is to create a game where the button runs away from you.  Simple CLICK ME button, but every time you get close to it with the mouse it moves to a random locaton.
        //  It took several tries but I think that these are the global variables I need to make this work.
        private int randNum;
        private int xLoc;
        private int yLoc;
        private int xAct;
        private int yAct;

        public startBtn()
        {
            InitializeComponent();
            //  Set the button to a random location on the form.
            setLoc();
            

        }



        private void Form1_Load(object sender, EventArgs e)
        {
            //  empty function.  I am still not comfortable erasing these. 
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            int colorNum = 0;
            colorNum = GenRandom(1, 5);

            if (colorNum == 1)
            {
                // if 1 make it RED.
                btn1.BackColor = System.Drawing.Color.Red;

            }
            else if (colorNum == 2)
            {
                // if 2 make it BLUE.
                btn1.BackColor = System.Drawing.Color.Blue;

            }
            else if (colorNum == 3)
            {
                // if 3 make it GREEN
                btn1.BackColor = System.Drawing.Color.Green;

            }
            else
            {
                //  I am proud of this one.  I though why not add the random number generator to the color  selection of the button.
                btn1.BackColor = Color.FromArgb(GenRandom(0, 256), GenRandom(0, 256), GenRandom(0, 256));

            }

            //  Backup plan in case I can not get the button to move when the mouse gets close to it.
            // setLoc();

        }

        public void setLoc()
        {
            //  random x and y to locate the button.  Setting 100 as the minimum for the x and 125 to the y coord.  With the maxium being the width of the window - 250 pixels.
            //  that should keep the button inside the form.
            xLoc = GenRandom(100, this.ClientSize.Width - 250);
            yLoc = GenRandom(125, this.ClientSize.Height - 250);

            //  set the button to the new location.
            btn1.Location = new Point(xLoc, yLoc);
        }

        private int GenRandom(int min, int max)
        {
            //function to produce the random number.
            randNum = 0;

            Random random = new Random();

            return random.Next(min, max);


        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            //Variable x and y to store the whole number location of the mouse.  Where is the mouse?
            xAct = e.X;
            yAct = e.Y;


            // Embarassingly I forgot the ".Text" and like to never have figured out why this was not working.  Grumble.
            txtX.Text = xAct.ToString();
            txtY.Text = yAct.ToString();
        }

        private void Form1_CursorChanged(object sender, EventArgs e)
        {
            // setLoc();  That did not work, but I am not discouraged.  I think defining an area around the button is the way to go. 
        }

        private void btn1_MouseEnter(object sender, EventArgs e)
        {
            //  That worked.  It was actually way easier than I was expecting.  Using the Mouse Enter event to trigger the setLoc() function when the mouse is over the button.
            setLoc();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("YOU DID IT!");
            btn1.Visible = false;
            btnStart.Visible = true;
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btn1.Visible = true;
            btnStart.Visible = false;

        }
    }
}
