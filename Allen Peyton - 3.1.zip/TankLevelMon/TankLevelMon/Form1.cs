﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace TankLevelMon
{
    public partial class Form1 : Form
    {
       
        // CONSTANT VALUES
        // Adjust the hardcoded items here!!!
        
        private const double MaxSensorValue = 5.0;       // Maximum sensor voltage reading
        private const double MinSensorValue = 0.0;       // Minimum sensor voltage reading
        private const double PsiConversionFactor = 2.0;  // Converts voltage to PSI (0-5V to 0-10PSI)
        private const double InchesConversionFactor = 26.78; // Converts PSI to material height in inches
        private const double GallonsPerCubicInch = 1.0 / 231; // Conversion factor for cubic inches to gallons

        // Current sensor value (main data source for calculations)
        private double _sensorValue = 0.0;

       
        // FORM INITIALIZATION
        
        public Form1()
        {
            InitializeComponent();
            InitializeControls();
        }

        
        /// Sets up initial control states and default values
       
        private void InitializeControls()
        {
            // Configure progress bar range (0-100%)
            lvlBar.Minimum = 0;
            lvlBar.Maximum = 100;

            // Set default values for the UI elements

            lblSensorRead.Text = "0.0";          // set sensor display
            txtRadius.Text = "48.0";             // Default tank diameter (inches)
            UpdateUI();                          // Perform initial calculations
        }

        
        // EVENT HANDLERS
        //Handles the button pushes and the updates if the Diameter is changed.
       
        private void DecBtn_Click(object sender, EventArgs e) => AdjustSensorValue(-0.1);
        private void IncBtn_Click(object sender, EventArgs e) => AdjustSensorValue(0.1);
        private void txtRadius_TextChanged(object sender, EventArgs e) => UpdateUI();


        //LOGIC METHODS

        /// Set the min and max values for the sensor.  Tried the use Math.Clamp but it didn't work.  I read about the function and thought I would try it.
        /// Below is a work around.  Keeps the sensor value within the valid range.


        private double Clamp(double value, double min, double max)
        {
            return (value < min) ? min : (value > max) ? max : value;
        }

 
        /// Adjusts sensor value while maintaining valid range
        private void AdjustSensorValue(double delta)
        {
            _sensorValue = Clamp(_sensorValue + delta, MinSensorValue, MaxSensorValue);
            UpdateUI();
        }

        
        /// Main update method that refreshes all UI elements
        
        private void UpdateUI()
        {
            // Update sensor value display.  Format to 1 decimal place.
            lblSensorRead.Text = _sensorValue.ToString("F1");

            // Perform all calculations
            var (psiValue, materialHeight, gallons) = CalculateValues();

            // Update progress bar value based on sensor value. Simple times 20 to get percentage.
            var progressValue = (int)(_sensorValue * 20); // 5V * 20 = 100%
            UpdateProgressBar(progressValue);

            // Update display labels with calculated values
            UpdateLabels(psiValue, materialHeight, gallons);

            // Update status color based on fill level
            UpdateStatusColor(progressValue);
        }


        /// Performs all physical calculations for display
        ///I really like the Math Library.  It makes things so much easier.
        private (double psi, double height, double gallons) CalculateValues()
        {
            // Get validated tank radius from user input
            var tankRadius = ValidateAndGetRadius();

            // Pressure calculation (PSI)
            var psiValue = _sensorValue * PsiConversionFactor;

            // Material height calculation (inches)
            var materialHeight = Math.Round(psiValue * InchesConversionFactor, 1);

            // Volume calculations
            var volume = Math.PI * Math.Pow(tankRadius, 2) * materialHeight;
            var gallons = Math.Round(volume * GallonsPerCubicInch, 1);

            return (psiValue, materialHeight, gallons);
        }

        
        /// Validates checks if its a number and converts tank diameter input to radius
        /// Radius in inches (half of diameter)
        private double ValidateAndGetRadius()
        {
            // Try to parse input with error handling
            if (double.TryParse(txtRadius.Text, out double diameter) && diameter > 0)
                return diameter / 2;

            // Show error message for invalid input
            MessageBox.Show("Please enter a valid tank diameter",
                          "Input Error",
                          MessageBoxButtons.OK,
                          MessageBoxIcon.Warning);

            // Return default value for 48" diameter tank
            return 24.0;
        }


        // UI UPDATE METHODS

        /// Updates progress bar value and keeps the values within the range. 
        /// I dont think this is technically needed since the value is calculated from the sensor value.
        /// But it was good practice.

        private void UpdateProgressBar(int value)
        {
            value = (int)Clamp(value, lvlBar.Minimum, lvlBar.Maximum);
            lvlBar.Value = value;
        }

        /// Updates all value display labels
       
        private void UpdateLabels(double psi, double height, double gallons)
        {
            lblPress.Text = psi.ToString("F1");     // PSI display
            lblHeight.Text = height.ToString("F1"); // Height display
            lblGallon.Text = gallons.ToString("F1"); // Volume display
        }

        
        /// Changes status label color based on fill percentage
      
        private void UpdateStatusColor(int value)
        {
            // Color thresholds:
            // - Red: 0-20%
            // - Orange: 21-79%
            // - Green: 80-100%
            if (value <= 20)
                label9.ForeColor = Color.Red;
            else if (value <= 79)
                label9.ForeColor = Color.DarkOrange;
            else
                label9.ForeColor = Color.Green;
        }
    }
}