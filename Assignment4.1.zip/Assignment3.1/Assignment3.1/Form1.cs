﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;


namespace TankLevelMon
{
    public partial class Form1 : Form
    {
        // Custom exception for invalid tank size input.
        public class InvalidTankSizeException : Exception
        {
            // Specialized constructor
            public InvalidTankSizeException(string message)
                : base($"Tank Error: {message}") { }
        }

        // Custom exception for sensor overload.  This cannot be triggered in the simulation but would be a real world issue.
        // In real world applications I would have this in the function that reads the sensor data.  In simulation it is not needed.
        public class SensorValueException : Exception
        {
            public SensorValueException(double currentValue)
                : base($"DANGER! Sensor overload: {currentValue}V exceeds 5V limit!") { }
        }

        // CONSTANT VALUES
        // Adjust the hardcoded items here!!!

        private const double MaxSensorValue = 5.0;       // Maximum sensor voltage reading
        private const double MinSensorValue = 0.0;       // Minimum sensor voltage reading
        private const double PsiConversionFactor = 2.0;  // Converts voltage to PSI (0-5V to 0-10PSI)
        private const double InchesConversionFactor = 26.78; // Converts PSI to material height in inches
        private const double GallonsPerCubicInch = 1.0 / 231; // Conversion factor for cubic inches to gallons

        // Current sensor value (main data source for calculations)
        private double _sensorValue = 0.0;
        private bool isSimulating = false; // Flag for simulation mode (not used in this snippet)

        //First Array to store sensor readings for charting.
        private double[] sensorReadings = new double[20]; // Array to store sensor readings for charting
        private int sensorIndex = 0; // Index for storing sensor readings

        // Second Array to store Who filled the unit.  I am doing this on as a list.
        private List<string> fillLog = new List<string>();  // Tracks fill history
        private const int MaxFillLogEntries = 20;           // Max history entries

        // FORM INITIALIZATION

        public Form1()
        {
            InitializeComponent();
            InitializeControls();
        }


        // Sets up initial control states and default values

        private void InitializeControls()
        {
            // Configure the chart
            sensorChart.Series.Clear();
            var series = new Series("Sensor Readings")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 2
            };
            sensorChart.Series.Add(series);

            // Configure progress bar
            lvlBar.Minimum = 0;
            lvlBar.Maximum = 100;

            // Set default values
            lblSensorRead.Text = "0.0";
            txtRadius.Text = "48.0";
            UpdateUI();
        }




        // EVENT HANDLERS
        //Handles the button pushes and the updates if the Diameter is changed.

        private void DecBtn_Click(object sender, EventArgs e) => AdjustSensorValue(-0.1);

        // This area would be where the sensor data would be read in a real world application.  In this case it is just a simulation.
        // This is also where the error handling for the sensor overload would be placed.
        private void IncBtn_Click(object sender, EventArgs e) => AdjustSensorValue(0.1);
        private void txtRadius_TextChanged(object sender, EventArgs e) => UpdateUI();

        // Accroding to the internet async keep the delay from locking up the UI.  It seems to work.
        private async void btnSim_Click(object sender, EventArgs e)
        {
            // Toggle simulation state use as a flag to start and stop the while loop.
            isSimulating = !isSimulating;
            // Do the opposite of what it is.
            //This is actually a new method for me.  I like it alot much cleaner than the if else method.
            btnSim.Text = isSimulating ? "Stop Simulation" : "Start Simulation";
            // Change the button color to match the state.
            btnSim.BackColor = isSimulating ? Color.Red : Color.Lime;

            while (isSimulating)
            {
                // This is where the sensor value would be read in a real world application.  In this case it is just a simulation.
                //if (_sensorValue < MinSensorValue || _sensorValue > MaxSensorValue)
                //{
                //    throw new SensorValueException(
                //        $"CRITICAL: Sensor reading Error " +
                //        $"(Valid range: 0 - 5V DC)");
                //}

                // Cycle sensor value between 0-5V
                if (_sensorValue >= MaxSensorValue)
                {
                    while (_sensorValue > MinSensorValue && isSimulating)
                    {
                        AdjustSensorValue(-0.1);
                        await Task.Delay(250); // Adjusted the delay in milliseconds
                    }
                }
                else
                {
                    AdjustSensorValue(0.1);
                    // Use await to prevent UI lockup during delay works with the async tag.
                    await Task.Delay(250); // Adjusted the delay in milliseconds
                }
            }
        }

        //LOGIC METHODS

        /// Set the min and max values for the sensor.  Tried the use Math.Clamp but it didn't work.  I read about the function and thought I would try it.
        /// Below is a work around.  Keeps the sensor value within the valid range.


        private double Clamp(double value, double min, double max)
        {
            return (value < min) ? min : (value > max) ? max : value;
        }


        /// Adjusts sensor value while maintaining valid range
        private void AdjustSensorValue(double delta)
        {
            _sensorValue = Clamp(_sensorValue + delta, MinSensorValue, MaxSensorValue);
            UpdateUI();
        }


        /// Main update method that refreshes all UI elements

        /// Main update method that refreshes all UI elements

        private void UpdateUI()
        {
            try
            {
                lblSensorRead.Text = _sensorValue.ToString("F1");



                var (psiValue, materialHeight, gallons) = CalculateValues();
                var progressValue = (int)(_sensorValue * 20);
                UpdateProgressBar(progressValue);
                UpdateLabels(psiValue, materialHeight, gallons);
                UpdateStatusColor(progressValue);

                //Update Sensor Readings Array
                UpdateSensorArray(_sensorValue);


                // Update Chart
                UpdateChart();

                Console.WriteLine($"Stored Readings: {string.Join(", ", sensorReadings)}");
            }
            catch (InvalidTankSizeException ex)
            {
                MessageBox.Show(ex.Message, "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtRadius.Text = "48.0";
                UpdateUI();
            }
        }

        // Updates the chart with sensor readings
        private void UpdateChart()
        {
            if (!sensorChart.Series.Any(s => s.Name == "Sensor Readings"))
            {
                sensorChart.Series.Add("Sensor Readings");
                sensorChart.Series["Sensor Readings"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            }

            sensorChart.Series["Sensor Readings"].Points.Clear();

            // Plot newest value first
            for (int i = 0; i < sensorReadings.Length; i++)
            {
                sensorChart.Series["Sensor Readings"].Points.AddY(sensorReadings[i]);
            }
        }



        /// Performs all physical calculations for display
        ///I really like the Math Library.  It makes things so much easier.
        private (double psi, double height, double gallons) CalculateValues()
        {
            // Get validated tank radius from user input
            var tankRadius = ValidateAndGetRadius();

            // Pressure calculation (PSI)
            var psiValue = _sensorValue * PsiConversionFactor;

            // Material height calculation (inches)
            var materialHeight = Math.Round(psiValue * InchesConversionFactor, 1);

            // Volume calculations
            var volume = Math.PI * Math.Pow(tankRadius, 2) * materialHeight;
            var gallons = Math.Round(volume * GallonsPerCubicInch, 1);

            return (psiValue, materialHeight, gallons);
        }


        /// Validates checks if its a number and converts tank diameter input to radius
        /// Radius in inches (half of diameter)
        private double ValidateAndGetRadius()
        {
            const double minDiameter = 12.0;  // 1 foot minimum
            const double maxDiameter = 120.0; // 10 feet maximum

            // Original parsing check
            if (!double.TryParse(txtRadius.Text, out double diameter) || diameter <= 0)
            {
                throw new InvalidTankSizeException("Bad number! Use 12-120 inches.");
            }

            // New range check
            if (diameter < minDiameter || diameter > maxDiameter)
            {
                throw new InvalidTankSizeException(
                    $"Tank diameter must be between {minDiameter}-{maxDiameter} inches."
                );
            }

            return diameter / 2;
        }


        // UI UPDATE METHODS

        /// Updates progress bar value and keeps the values within the range. 
        /// I dont think this is technically needed since the value is calculated from the sensor value.
        /// But it was good practice.

        private void UpdateProgressBar(int value)
        {
            value = (int)Clamp(value, lvlBar.Minimum, lvlBar.Maximum);
            lvlBar.Value = value;
        }

        /// Updates all value display labels

        private void UpdateLabels(double psi, double height, double gallons)
        {
            lblPress.Text = psi.ToString("F1");     // PSI display
            lblHeight.Text = height.ToString("F1"); // Height display
            lblGallon.Text = gallons.ToString("F1"); // Volume display
        }


        /// Changes status label color based on fill percentage

        private void UpdateStatusColor(int value)
        {
            // Color thresholds:
            // - Red: 0-20%
            // - Orange: 21-79%
            // - Green: 80-100%
            if (value <= 20)
                label9.ForeColor = Color.Red;
            else if (value <= 79)
                label9.ForeColor = Color.DarkOrange;
            else
                label9.ForeColor = Color.Green;
        }

        private void UpdateSensorArray(double newValue)
        {
            // Shift all values forward (from last index to index 1)
            for (int i = sensorReadings.Length - 1; i > 0; i--)
            {
                sensorReadings[i] = sensorReadings[i - 1];
            }

            // Insert new value at the front
            sensorReadings[0] = newValue;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate inputs
                var validationErrors = new List<string>();

                // Check 1: Textbox not empty
                if (string.IsNullOrWhiteSpace(txtWhoFilled.Text))
                {
                    validationErrors.Add("• Operator name cannot be empty");
                }

                // Check 2: Checkbox must be checked
                if (!chkConfirmed.Checked) // Replace with your checkbox name
                {
                    validationErrors.Add("• You must confirm the operation");
                }

                // Show errors if any
                if (validationErrors.Count > 0)
                {
                    MessageBox.Show(
                        $"Please fix these errors:\n{string.Join("\n", validationErrors)}",
                        "Validation Failed",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                // --- Proceed with valid data ---

                // Stop simulation if running
                isSimulating = false;
                btnSim.Text = "Start Simulation";
                btnSim.BackColor = Color.Lime;

                // Set to max value
                _sensorValue = MaxSensorValue;

                // Log the fill operation
                if (fillLog.Count >= MaxFillLogEntries)
                {
                    fillLog.RemoveAt(0);
                }

                fillLog.Add($"{DateTime.Now:HH:mm:ss} - " +
                           $"{txtWhoFilled.Text.Trim()} (Confirmed)");

                // Reset UI elements
                chkConfirmed.Checked = false;
                txtWhoFilled.Clear();

                UpdateUI();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Critical error during fill operation: {ex.Message}",
                    "System Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

    }
}